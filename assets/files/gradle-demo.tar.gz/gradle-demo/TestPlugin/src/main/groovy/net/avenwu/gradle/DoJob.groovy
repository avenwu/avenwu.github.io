package net.avenwu.gradle

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.TaskAction

/**
 * Created by aven on 5/9/16.
 */
public class DoJob extends DefaultTask {
    def value

    @TaskAction
    def echo() {
        println(value)
    }
}
