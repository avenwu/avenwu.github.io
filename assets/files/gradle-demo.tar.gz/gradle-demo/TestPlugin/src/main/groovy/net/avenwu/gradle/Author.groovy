package net.avenwu.gradle

/**
 * Created by aven on 5/9/16.
 */
class Author {
    def name
    def email
}
